#!/bin/bash

git remote set-url --add --push origin https://github.com/wraytw/Abacus.git
git remote set-url --add --push origin ssh://cs2450Group6@vs-ssh.visualstudio.com:22/_ssh/Abacus
