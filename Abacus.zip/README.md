# Abacus project for CS 2450

This is the repository for our Team projects for CS 2450.

## Project Setup

Install `node.js` from [nodejs.org](https://nodejs.org/en/). It comes with [npm](https://www.npmjs.com/) already, so just to reduce the number of things you need to download, let's just use npm for our package management.

### To install dependancies

1. Open a command prompt
2. `cd` into the project root directory
3. Enter the command `npm install`
4. To start the app, enter `npm start`
5. To build the app into a distributable format, enter `npm build` and then the results of the build will be written to the `build` directory

## React reference

Here are some good resources for React.js:

- [React website](https://reactjs.org/)
- [Codecademy](https://www.codecademy.com/learn/react-101)
- [http://devdocs.io/ (Documentation aggregator)](http://devdocs.io/)

## Example of concept

5 * 5 = 25 : I would have 2 beads in the 10's column, and either 5 ones or a single 5 bead in the one's column.
so if we multiply each culumns sum by either 1,10,100,...,etc. then we can return a accurate answer.
just as if we were using an abacus... fancy

## Notes

abacus thoughts - RR

- if each of the  columns of 5 beads represent the 1,10,100,...,etc. values and each of the upper two beads represent values greater than 5's (respectivly) then we can create containers that each have a value of 1, and for each bead that have been moved into a positive position by the time the check answer button is pressed
- we need only add the sum of each column up to verify it matches the answer.
- and each column would retun a value multiplied by its respective value position.
