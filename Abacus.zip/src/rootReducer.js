import { combineReducers } from "redux";

import abacus from "./Abacus/reducer";
import quiz from './quiz/reducer';

export default combineReducers({ abacus, quiz });