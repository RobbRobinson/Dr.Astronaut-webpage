
import { createStore } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import rootReducer from './rootReducer';

let store;

if (process.env.NODE_ENV === 'development')
    store = createStore(rootReducer, composeWithDevTools());
else
    store = createStore(rootReducer);

store.subscribe(console.log);
//TODO: Persist difficulty level to localstorage
export default store;
