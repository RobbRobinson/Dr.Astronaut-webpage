import React, { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'react-font-awesome-5';

class CustomCheckBox extends PureComponent {
    componentDidMount() { }

    render() {
        const { checked, children } = this.props;
        return (

            <Fragment>
                {checked ?
                    <Icon.CheckSquare.regular />
                    : <Icon.Square.regular />}
                {/* <Icon name={checked ? 'check-square' : 'square'} />&nbsp; */}
                <span style={{ marginLeft: 2 }}> {children}</span>
            </Fragment>);
    }
}

CustomCheckBox.propTypes = {
    checked: PropTypes.bool.isRequired,
    children: PropTypes.any
};

export default CustomCheckBox;
