import React from 'react';
import PropTypes from 'prop-types';
import { Jumbotron, Container } from 'reactstrap';


export default function PageLayout({ children }) {
    return (
        <Container>
            <Jumbotron>
                {children}
            </Jumbotron>
        </Container>
    );

}

PageLayout.propTypes = {
    children: PropTypes.object.isRequired
};
