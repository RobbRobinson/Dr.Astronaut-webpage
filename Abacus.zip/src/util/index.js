/**@module util */
import WithTooltip from "./WithTooltip";
import Icon from "./Icon";
import CustomCheckBox from './CustomCheckBox';
import PageLayout from './PageLayout';

export { WithTooltip, Icon, CustomCheckBox, PageLayout };

/**
 * Returns a random integer value that falls in the given range
 * 
 * @export
 * @param {any} min The inclusive minimum bound
 * @param {any} max The exclusive maximum bound
 * @returns {number} A number that falls in the given range
 */
export function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    //The maximum is exclusive and the minimum is inclusive
    const val = Math.floor(Math.random() * (max - min)) + min;
    return val;
}

/**
 * Randomly returns either true or false
 * 
 * @export
 * @returns {boolean}
 */
export function getRandomBool(){
    //eslint-disable-next-line
    return Math.random() >= 0.5;
}