import React, { Component, Fragment } from "react";
import PropTypes from 'prop-types';

import { Tooltip } from "reactstrap";

export default class WithTooltip extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false
        };
    }
    static defaultProps = {

        container: 'body',
        autohide: true,
        placement: 'auto'
    }

    static propTypes = {
        children: PropTypes.oneOfType([PropTypes.element, PropTypes.arrayOf(PropTypes.element), PropTypes.string]).isRequired,
        target: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.func,
            PropTypes.element // instanceof Element (https://developer.mozilla.org/en-US/docs/Web/API/Element)
        ]).isRequired,
        // Where to inject the popper DOM node, default to body
        container: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.element]),
        // optionally override show/hide delays - default { show: 0, hide: 250 }
        delay: PropTypes.oneOfType([
            PropTypes.shape({ show: PropTypes.number, hide: PropTypes.number }),
            PropTypes.number
        ]),
        className: PropTypes.string,
        // Apply class to the inner-tooltip
        innerClassName: PropTypes.string,
        // optionally hide tooltip when hovering over tooltip content - default true
        autohide: PropTypes.bool,
        // convenience attachments for popover
        placement: PropTypes.oneOf([
            'auto',
            'auto-start',
            'auto-end',
            'top',
            'top-start',
            'top-end',
            'right',
            'right-start',
            'right-end',
            'bottom',
            'bottom-start',
            'bottom-end',
            'left',
            'left-start',
            'left-end'
        ]),
        canShow: PropTypes.bool.isRequired,
        tooltip: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.element]).isRequired
    }

    render() {
        const { children, target, placement, tooltip, canShow } = this.props;
        const { isOpen } = this.state;

        return (
            <Fragment>
                {children}
                <Tooltip placement={placement} target={target} isOpen={canShow && isOpen} 
                    toggle={() => this.setState({ isOpen: !isOpen })}>
                    {tooltip}
                </Tooltip>
            </Fragment>);
    }
}