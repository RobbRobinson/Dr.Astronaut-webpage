
import App from './components';

export default App;
