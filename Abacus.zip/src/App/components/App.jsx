import React, { Fragment } from 'react';
import { Provider } from "react-redux";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Results } from '../../pages/';
import NavBar from './NavBar';
import {
    Home,
    NotFound404,
    SandboxMode,
    Learn,
    Teacher,
    About
} from '../../pages';

import {
    DifficultySelector,
    QuizMode
} from '../../quiz';

import store from "../../store";
import './style/App.css';

/**
 * The App component sets up all of the routes for the app. 
 */
function App() {
    return (
        <Provider store={store}>
            <Router>
                <Fragment>
                    <NavBar />
                    <main className="App">
                        <Switch>
                            <Route path="/sandbox" component={SandboxMode} />
                            <Route path="/start" component={DifficultySelector} />
                            <Route path="/quiz" component={QuizMode} />
                            <Route path="/learn" component={Learn} />
                            <Route path="/teacher" component={Teacher} />
                            <Route path="/about" component={About} />
                            <Route path="/results" component={Results} />
                            <Route exact path="/" component={Home} />
                            <Route component={NotFound404} />
                        </Switch>
                    </main>
                </Fragment>
            </Router>
        </Provider>
    );
}


export default App;
