import React, { Component } from 'react';
import {
    Navbar,
    NavbarToggler,
    Collapse,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink
} from "reactstrap";

import { NavLink as RouteNavLink } from 'react-router-dom';

class AppNavBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            collapsed: false
        };

        this.toggleNavbar = this.toggleNavbar.bind(this);
    }

    toggleNavbar() {
        this.setState({ collapsed: !this.state.collapsed });
    }

    static propTypes = {

    }

    render() {
        return (
            <Navbar dark expand="md">
                <NavbarBrand tag={RouteNavLink} to="/" tabIndex={0}><em>UVU</em>Bacus</NavbarBrand>
                <NavbarToggler onClick={this.toggleNavbar} />
                <Collapse isOpen={!this.state.collapsed} navbar>
                    <Nav navbar>
                        <NavItem tabIndex={1}>
                            <NavLink tag={RouteNavLink} to="/teacher">Teacher Login</NavLink>
                        </NavItem>
                        <NavItem tabIndex={4}>
                            <NavLink tag={RouteNavLink} to="/about">About</NavLink>
                        </NavItem>
                    </Nav>
                </Collapse>

            </Navbar>);
    }
}

export default AppNavBar;
