import React from 'react';
import Bead from '../Bead';

import { shallow } from "enzyme";
describe('Bead', () => {
    it('renders without crashing', () => {
        
        shallow(<Bead />);
    });
});
