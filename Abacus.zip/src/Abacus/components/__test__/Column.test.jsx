import React from 'react';
import { shallow } from "enzyme";
import {Column} from "../Column";


describe('Column', () => {
    it('renders without crashing', () => {
        shallow(<Column />);
    });
});
