import React from 'react';
import { shallow } from "enzyme";
import { Abacus } from '../Abacus';

describe('Abacus', () => {
    it('renders without crashing', () => {
        //eslint-disable-next-line

        shallow(<Abacus />);

    });
});
