/**@module abacus */
import React, { Component, StrictMode } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { CardText } from "reactstrap";
import _ from "lodash";

import Column from "./Column";
import { init } from "../actions";

import "./style/Abacus.css";



const AbacusContext = React.createContext();

/**
 *
 * @typedef AbacusProps
 * @kind typedef
 * @prop {number} columns The number of columns to generate
 * @prop {function} init Initialize the abacus state in redux
 * @prop {boolean} showValues Whether to display the values for each column
 * @prop {boolean} showValuesOnBead Whether or not to show the value on each bead
 */

/**
 * Represents an abacus. Can be configured via props whether or not to show values for each column or bead.
 *
 * @export
 * @class Abacus
 * @kind class
 * @extends {Component<AbacusProps>}
 */
class Abacus extends Component {

    state = {};

    /**
     * Render the abacus into view
     *
     * @returns {Abacus}
     * @memberof Abacus
     */
    render() {

        const { showValuesOnBeads, abacus } = this.props;
        const columns = Object.keys(abacus.columns).length;

        const columnProps = i => ({
            rank: parseInt(i), // makes sure that rank is an integer, rather than a string            
            showValuesOnBeads
        });

        const columnComponents = _(0).range(columns).map((a, i) => <Column key={i} {...columnProps(i)} />).value();

        return (
            <AbacusContext.Provider value={abacus}>
                <CardText tag="div" className="abacus">
                    <div className="wrapper">
                        {columnComponents}
                    </div>
                </CardText>
            </AbacusContext.Provider>

        );
    }

    static propTypes = {

        abacus: PropTypes.any.isRequired,
        init: PropTypes.func,
        showValues: PropTypes.bool,
        showValuesOnBeads: PropTypes.bool
    }

    static defaultProps = {
        showValues: false,
        showValuesOnBeads: false
    }
}


// This function takes a component...
export function withAbacus(Component) {
    // ...and returns another component...
    return function WithAbacusComponent(props) {
        // ... and renders the wrapped component with the context theme!
        // Notice that we pass through any additional props as well
        return (
            <AbacusContext.Consumer>
                {abacus => <Component abacus={abacus} {...props} />}
            </AbacusContext.Consumer>
        );
    };
}
/**
 * Maps the Redux state to the Abacus component
 *
 * @param {AbacusState} state
 * @param {any} ownProps
 * @returns {{columns: number}}
 * @private
 * @function Bead.mapstateToProps
 */
function mapStateToProps({ abacus }) {
    return { abacus };
}

export default connect(mapStateToProps, { init })(Abacus);
