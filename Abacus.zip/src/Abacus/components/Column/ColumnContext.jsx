import React from 'react';

export const ColumnContext = React.createContext(0);

export function withColumnContext(Component) {
    function ColumnDependentComponent(props) {
        return (
            <ColumnContext.Consumer>
                {column => <Component column={column} {...props} />}
            </ColumnContext.Consumer>);
    }

    ColumnDependentComponent.displayName = `WithColumnContext(${Component.displayName || Component.name})`;
    return ColumnDependentComponent;
}