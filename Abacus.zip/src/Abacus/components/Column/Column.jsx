/**@module abacus */
import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import { Badge } from "reactstrap";
import _ from "lodash";
import { connect } from "react-redux";

import { pushBead, popBead } from "../../actions";
import { withAbacus } from '../Abacus';
import Bead, { BeadPlaceholder } from "../Bead";
import { ColumnContext } from "./ColumnContext";
import { SectionContext } from "./SectionContext";

const mapBeads = (values) => {
    const { available, selectedCount, isTop } = values;
  
    const beads = _(0).range(available + 1)
        .map(i => {
            const realIndex = i <= selectedCount ? i : i - 1;

            if (i === selectedCount)
                return <BeadPlaceholder key={`placeholder_${i}`} />;

            return (
                <Bead key={realIndex}
                    index={realIndex}
                    active={i <= selectedCount}
                    {...values}
                />);
        });

    // Reverse if top row, because that's how abacuses work
    return (isTop ? beads.reverse() : beads).value();
};

/**
 * 
 * 
 * @export
 * @class Column
 * @kind class
 * @extends {PureComponent}
 */
export class Column extends PureComponent {

    /**
     * Creates an instance of Column.
     * @param {any} props 
     * @constructor
     * @kind member
     * @memberof Column
     */
    constructor(props) {
        super(props);

        this.state = Column.getDerivedStateFromProps(props);

        //this.handleBeadClick = this.handleBeadClick.bind(this);
    }
    state = {
        topSelected: 0,
        selected: 0
    };

    static getDerivedStateFromProps(props) {

        const { abacus, rank, showValuesOnBeads } = props;

        const {
            topCount,
            bottomCount,
            columns: {
                [rank]: {
                    topCount: topSelected,
                    bottomCount: bottomSelected
                }
            },

            total
        } = abacus;

        return {
            total,
            rank,
            showValuesOnBeads,
            topSection: {
                isTop: true,
                available: topCount,
                selectedCount: topSelected
            },
            bottomSection: {
                isTop: false,
                available: bottomCount,
                selectedCount: bottomSelected
            }
        };
    }

    render() {
        const { showValues } = this.props;

        const { total, rank, topSection, bottomSection } = this.state;

        const topBeadElements = mapBeads(topSection);
        const beadElements = mapBeads(bottomSection);

        return (
            <ColumnContext.Provider value={rank}>
                <div className="column-wrapper">
                    <div className="column">
                        <div className="top">
                            <SectionContext.Provider value={topSection}>
                                {topBeadElements}
                            </SectionContext.Provider>
                        </div>
                        <hr />
                        <div className="main">
                            <SectionContext.Provider value={bottomSection}>
                                {beadElements}
                            </SectionContext.Provider>
                        </div>

                        {/* eslint-disable no-magic-numbers */}
                        {!showValues ? null :
                            <div className="column-value bg-light">
                                {total}
                            </div>
                        }
                    </div>
                </div>
            </ColumnContext.Provider>);
    }

    static propTypes = {
        abacus: PropTypes.any.isRequired,

        rank: PropTypes.number.isRequired,

        showValues: PropTypes.bool,
        showValuesOnBeads: PropTypes.bool,
        showAsHex: PropTypes.bool
    }
}

// function mapStateToProps(state, ownProps) {
//     const { rank } = ownProps;
//     const {
//         topVal,
//         bottomVal,
//         topCount: topAvailable,
//         bottomCount: baseAvailable,
//         columns = {}
//     } = state.abacus;

//     const {
//         topCount: topSelected = 0,
//         bottomCount: baseSelected = 0
//     } = columns[rank] || {};

//     return {
//         columnCount: Object.keys(columns).length,
//         topVal,
//         bottomVal,

//         topAvailable,
//         baseAvailable,

//         topSelected,
//         baseSelected
//     };
// }

export default _.flowRight(
    connect(null, { pushBead, popBead }),
    withAbacus
)(Column);