import React from 'react';


export const SectionContext = React.createContext({
    isTop: false,
    available: 0,
    selectedCount: 0
});

export function withSectionContext(Component) {
    function SectionDependentComponent(props) {
        return (
            <SectionContext.Consumer>
                {section => <Component section={section} {...props} />}
            </SectionContext.Consumer>);
    }

    SectionDependentComponent.displayName = `WithSectionContext(${Component.displayName || Component.name})`;
    return SectionDependentComponent;
}