/**@module abacus */
import React, { PureComponent, Fragment } from "react";
import _ from 'lodash';
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Badge, Button } from "reactstrap";
import { getRowValueKey } from '../reducer';
import * as actions from "../actions";
import { withColumnContext } from './Column/ColumnContext';
import { withSectionContext } from "./Column/SectionContext";




export function BeadPlaceholder() {
    return <div className="bead-wrapper"> <div className="bead placeholder" />    </div>;
}

const isNotNaN = _.negate(_.isNaN);

/**
 *
 *
 * @class Bead
 * @kind class
 * @extends {PureComponent}
 */
class Bead extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {};
        this.handleBeadClick = this.handleBeadClick.bind(this);
    }

    handleBeadClick() {
        const { active, column, index, isTop } = this.props;

        console.assert(isNotNaN(column), 'Column must not be NaN', column);

        const handler = active ? this.props.popBead : this.props.pushBead;

        handler(index, column, isTop);
    }

    static propTypes = {
        active: PropTypes.bool.isRequired,

        isTop: PropTypes.bool.isRequired,
        showValuesOnBeads: PropTypes.bool.isRequired,

        selectedCount: PropTypes.number.isRequired,
        singleValue: PropTypes.number.isRequired,

        column: PropTypes.number.isRequired,
        index: PropTypes.number.isRequired,

        pushBead: PropTypes.func,
        popBead: PropTypes.func,

        showTooltip: PropTypes.bool
    };

    static defaultProps = {
        active: false
    };

    render() {
        const { singleValue: value, showValuesOnBeads, active, column, index, isTop, selectedCount } = this.props;

        console.assert(_.isNumber(column), 'Column was not a number', column);
        const uniqueId = `bead_${column}_${isTop ? 'top' : ''}_${index}`;

        const onClick = () => this.handleBeadClick(index, isTop, active, selectedCount);
        let className = 'bead';

        if (active)
            className += ' selected';

        return (
            <Fragment>
                <div className="bead-wrapper">
                    <Button tag="div" color={isTop ? 'primary' : 'danger'} id={uniqueId} className={className} onClick={onClick}>
                        {showValuesOnBeads && <Badge pill>{value}</Badge>}
                    </Button>
                </div>
                {/* {showTooltip &&
                    <Tooltip target={uniqueId} delay={0}>
                        Value: {value}
                    </Tooltip>} */}
            </Fragment>
        );
    }
}

export { Bead };

/**
 * Map values from the global state to the bead
 *
 * @function Bead.mapstateToProps
 * @param {AbacusState} state
 * @param {any} ownProps
 * @private
 */
function mapStateToProps(state, ownProps) {

    const valueKey = getRowValueKey(ownProps.isTop);
    const singleValue = state.abacus[valueKey];

    return { singleValue };
}

const { pushBead, popBead } = actions;

export default _.flowRight(
    withColumnContext,
    withSectionContext,
    connect(mapStateToProps, { pushBead, popBead })
)(Bead);
