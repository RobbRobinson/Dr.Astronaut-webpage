/** @namespace abacus */
import { initialState } from './reducer';

export const PUSH_BEAD = 'PUSH_BEAD';
export const POP_BEAD = 'POP_BEAD';
export const INIT = 'INIT_ABACUS';

/**
 * @typedef Action<T> 
 * @global
 * @type {object}
 * @kind typedef
 * @property {string} type The type of action being performed
 * @property {T} payload The payload of the action
 * @property {any} meta Optional information about the action
 * @template T
 */

/**
 * @typedef InitArgs Arguments used when initializing the abacus state
 * @property {number} topVal Value of a single top-row bead    
 * @property {number} bottomVal Value of a single bottom-row bead    
 * @property {number} topCount Number of beads in each column on the top row    
 * @property {number} bottomCount Number of beads in each column on the bottom row    
 * @property {number} columns The number of columns to use
 */

/* eslint-disable no-magic-numbers */
/**
 * Initialize the abacus
 * @export
 * @param {InitArgs} [args={bottomVal=1, bottomCount=5,topVal=5, topCount=1, columns=4}]  
 * @returns {Action}
 */
export function init(args = {}) {

    // Initialize any missing arguments with initial default values
    const {
        bottomVal = initialState.bottomVal,
        bottomCount = initialState.bottomCount,
        topVal = initialState.topVal,
        topCount = initialState.topCount,
        columns = Object.keys(initialState.columns).length
    } = args;

    return {
        type: INIT,
        payload: {
            bottomVal,
            bottomCount,
            topVal,
            topCount,
            columns
        }
    };
}

/* eslint-disable no-magic-numbers */

/**
 * @typedef BeadActionArgs
 * @param {number} rank The 'index' of the bead in the column
 * @param {number} col The index of the column containing the bead
 * @param {boolean} isTop Represents whether the bead should be in the top row or not
 */

/**
 * Push a bead on the column stack
 * 
 * @export
 * @param {number} rank The 'index' of the bead in the column
 * @param {number} col The index of the column containing the bead
 * @param {boolean} isTop Represents whether the bead should be in the top row or not
 * @returns {Action}
 */
export function pushBead(rank, col, isTop) {
    return {
        type: PUSH_BEAD,
        payload: {
            rank,
            col,
            isTop
        }
    };
}

/**
 * Pop a bead from the column stack
 * 
 * @export
 * @param {number} rank The 'index' of the bead in the column
 * @param {number} col The index of the column containing the bead
 * @param {boolean} isTop Represents whether the bead should be in the top row or not
 * @returns {Action}
 */
export function popBead(rank, col, isTop) {
    return {
        type: POP_BEAD,
        payload: {
            rank,
            col,
            isTop
        }
    };
}

/**
 * Resets the abacus and changes the number of columns to the specified value
 * 
 * @export
 * @param {number} columns The new number of columns to have
 * @returns {Action}
 */
export function changeNumColumns(columns) {

    return init({ columns });
}