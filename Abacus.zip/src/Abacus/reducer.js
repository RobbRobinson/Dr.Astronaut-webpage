/** @namespace AbacusApp */
/** @module abacus/reducer */
import _ from 'lodash';


import { INIT, POP_BEAD, PUSH_BEAD } from "./actions";


export const TOP_KEY = 'topCount';
export const BOTTOM_KEY = 'bottomCount';

/**
 *
 * @typedef ColumnState
 * @type {Object}
 * @property {number} topCount Number of beads active on the top row of this column
 * @property {number} bottomCount Number of beads active on the bottom row of this column
 *
 *
 * @typedef AbacusState
 * @type {Object}
 * @prop {number} base The base of the number, i.e. base-10, base-16
 * @prop {number} topVal Value of a single top-row bead
 * @prop {number} bottomVal Value of a single bottom-row bead
 * @prop {number} topCount Number of beads in each column on the top row
 * @prop {number} bottomCount Number of beads in each column on the bottom row
 * @prop {ColumnState[]} columns The collection of columns
 * @prop {number} total The total value held in the abacus
 *
 */

//TODO: refactor state to be more intuitive
// const initialStates = {
//     base: 10,

//     values: {
//         top: 1,
//         bottom: 5
//     },
//     count: {
//         top: 2,
//         bottom: 5
//     },
//     columns: {
//         [0]: {
//             count: {
//                 top: 2,
//                 bottom: 5
//             }
//         }
//     }
// };

export const INITIAL_NUM_COLUMNS = 4;


export const initialState = {
    base: 10,

    topVal: 5,
    bottomVal: 1,

    topCount: 1,
    bottomCount: 4,
    total: 0,

    columns: _(0).range(INITIAL_NUM_COLUMNS).reduce((total, next, i) => {
        return {
            ...total,
            [i]: {
                topCount: 0,
                bottomCount: 0
            }
        };
    }, {})
};

/**
 * Gets the key for the count of beads in the row or column, based on whether it is in the top section or not
 * @param {boolean} isTop
 */
export const getColumnCountKey = isTop => isTop ? 'topCount' : 'bottomCount';

/**
 * Gets the key for the value of a bead in either the top or bottom row
 * @param {boolean} isTop
 */
export const getRowValueKey = isTop => isTop ? 'topVal' : 'bottomVal';

/**
 * Returns a function to truncate a value based 
 * @param {boolean} isTop Whether the function should base teh trun
 */
const truncate = (isTop) =>
    /**
      * Restricts a the given value to fit within the bounds set by the abacus
      * 
      * @param {AbacusState} state The state of the abacus
      * @param {number} actual 
      * @returns {number} The truncated value
      */
    function (state, actual) {

        const key = getColumnCountKey(isTop);
        const limit = state[key];

        if (actual > limit)
            return limit;

        if (actual < 0)
            return 0;

        return actual;
    };

/**
 * Calculates the total value held in the abacus
 * @param {AbacusState} state The state of the abacus reducer
 */
function calculateTotal(state) {
    const { topVal, bottomVal } = state;

    // For now, just concatenate and parse the column values
    const total = _(state.columns).reduce((total, next) => {
        return `${total}${(next.topCount * topVal) + (next.bottomCount * bottomVal)}`;
    }, '');

    const parsedTotal = parseInt(total);
    return parsedTotal;
}

/**
 * Calculates a change in the state of a column in the abacus
 *
 * @param {AbacusState} state The state of the abacus reducer
 * @param {{ col: number, isTop: boolean }} row
 * @param {{ comparison: (colA: number, colB: number) => boolean, method: (colA: number, colB: number) => number, truncate:() }} reductionFunctions Functions used in reducing the column
 * @returns {AbacusState}
 */
function reduceColumn(state, row, reductionFunctions) {

    const { col, isTop } = row;
    const { comparison, method, truncate } = reductionFunctions;

    const key = getColumnCountKey(isTop);

    if (state.columns[col]) {
        const allColumns = state.columns;
        const column = state.columns[col];

        if (comparison(column[key], state[key])) {
            const newValue = truncate(state, method(column[key], state[key]));
            const next = {
                ...state,
                columns: {
                    ...allColumns,
                    [col]: {
                        ...column,
                        [key]: newValue
                    }
                }
            };

            return {
                ...next,
                total: calculateTotal(next)
            };
        }
    }
    return null;
}

/**
 *
 *
 * @param {AbacusState} state
 * @param {Action} action
 * @returns {AbacusState}
 */
function initReducer(state, action) {
    //eslint-disable-next-line
    const { bottomVal, bottomCount, topVal, topCount, base = 10, columns } = action.payload;

    const newColumns = {};

    for (let i = 0; i < columns; i++) {
        newColumns[i] = {
            bottomCount: 0,
            topCount: 0
        };
    }

    const newState = {
        base,
        bottomVal,
        topVal,
        bottomCount,
        topCount,
        columns: newColumns,
        total: 0
    };
    return newState;
}

/**
 * Calculates the new state when a bead is pushed
 *
 * @param {AbacusState} state
 * @param {Action<BeadActionArgs>} action
 * @returns {AbacusState}
 */
function pushBeadReducer(state, action) {
    const { rank, col, isTop } = action.payload;

    const key = getColumnCountKey(isTop);

    const selected = state.columns[col][key];
    const method = a => a + ((rank + 1) - selected);

    return reduceColumn(state, action.payload, {
        comparison: (colVal, allowed) => method(colVal) <= allowed,
        truncate: truncate(isTop),
        method
    });
}

/**
 * Calculates the new state when a bead is popped
 *
 * @param {AbacusState} state
 * @param {Action<BeadActionArgs>} action
 * @returns {AbacusState}
 */
function popBeadReducer(state, action) {
    const { rank, col, isTop } = action.payload;
    const key = getColumnCountKey(isTop);
    const selected = state.columns[col][key];

    const method = a => a - (selected - rank);

    return reduceColumn(state, action.payload, {
        comparison: colVal => colVal > 0,
        truncate: truncate(isTop),
        method
    });
}

/**
 * The root reducer of the app. This function takes care of state changes via Redux.
 * This state serves as the single source of truth for the state of the app
 * @export
 * @param {AbacusState} [state=initialState]
 * @param {Action} action
 * @returns {AbacusState}
 */
export default function abacusReducer(state = initialState, action) {

    switch (action.type) {

        case INIT:
            return { ...initReducer(state, action), total: 0 };

        case PUSH_BEAD: {
            const next = pushBeadReducer(state, action);
            if (next != null)
                return next;
            break;
        }

        case POP_BEAD: {
            const next = popBeadReducer(state, action);
            if (next != null)
                return next;
            break;
        }

        default:
            return state;
    }

    return state;
}
