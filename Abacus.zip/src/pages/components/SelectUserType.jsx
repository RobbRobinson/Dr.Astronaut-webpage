import React from 'react';
import { Container, Button, Col, Row, Card, CardHeader, CardTitle, CardSubtitle, CardBody } from 'reactstrap';
import { Link } from 'react-router-dom';

import { PageLayout } from "../../util";
function SelectUserType() {
    return (
        <PageLayout>
            <h1>  Select user type</h1>
            <Container>
                {/*  sm="6" md="6" lg="6" */}
                <Row>
                    <Col>
                        <Card>
                            <CardHeader>
                                <CardTitle>
                                    Teacher
                                </CardTitle>
                                <CardSubtitle>
                                    Sign in to manage your students
                                </CardSubtitle>
                            </CardHeader>
                            <CardBody>
                                <Button disabled>Log in</Button>

                            </CardBody>
                        </Card>
                    </Col>
                    <Col>
                        <Card>
                            <CardHeader>
                                <CardTitle>
                                    Student
                                </CardTitle>
                            </CardHeader>
                            <CardBody>
                                <Button tag={Link} color="primary" to="/quiz">
                                    Start
                                </Button>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </PageLayout>
    );
}
export default SelectUserType;
