import React from 'react';
import {
    Card,
    CardBody,
    CardHeader,
    CardTitle,
    CardSubtitle,
    Input,
    InputGroup,
    Button
} from 'reactstrap';
import PageLayout from '../../util/PageLayout';
import { Link } from 'react-router-dom';

const Teacher = () => (
    <PageLayout>
        <Card style={{ maxWidth: 500, margin: '0 auto' }}>
            <CardHeader>
                <CardTitle>
                    Teacher
                </CardTitle>
                <CardSubtitle>
                    Sign in to manage your students
                </CardSubtitle>
            </CardHeader>
            <CardBody>
                <InputGroup>
                    <Input placeholder="username" />
                </InputGroup>
                <InputGroup style={{ marginTop: '15px', marginBottom: '15px' }}>
                    <Input type="password" placeholder="password" />
                </InputGroup>
                <Button block tag={Link} to="/teacher" title="Teacher log in not yet set up" color="info">
                    Log in
                </Button>
            </CardBody>
        </Card>
    </PageLayout>
);

export default Teacher;
