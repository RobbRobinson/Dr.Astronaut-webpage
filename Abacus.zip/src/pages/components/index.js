
import Home from './Home';
import NotFound404 from './NotFound404';
import SandboxMode from './SandboxMode';
import SelectUserType from './SelectUserType';
import Learn from './Learn';
import Teacher from './Teacher';
import About from './About';
import Results from './Results';

export {
    Home,
    NotFound404,
    SandboxMode,
    SelectUserType,
    Learn,
    Teacher,
    About,
    Results
};
