/**@module abacus */
import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import Slider from 'react-rangeslider';
import {
    Container, Jumbotron,
    Card, CardBody,
    Collapse,
    CardHeader, CardTitle,
    Button,
    Popover, PopoverBody, PopoverHeader,
    ListGroupItem, ListGroup, ListGroupItemHeading
} from "reactstrap";
import { Icon } from 'react-font-awesome-5';

import { CustomCheckBox } from "../../util";
import Abacus from '../../Abacus/components/Abacus';
import { init, changeNumColumns } from '../../Abacus/actions';

import './style/sandbox.css';

/**
 * Allows free play with the abacus
 *
 * @export
 * @class SandboxMode
 * @typedef SandboxModeProps
 * @type {object}
 * @prop {number} columns
 * @extends {Component<SandboxModeProps>}
 */
class SandboxMode extends Component {
    /**
     * Creates an instance of SandboxMode.
     * @param {SandboxModeProps} props
     * @memberof SandboxMode
     */
    constructor(props) {
        super(props);

        this.toggleSettings = this.toggleSettings.bind(this);
    }

    state = {
        showValues: true,
        showValuesOnBeads: false,
        showSettings: false,
        showTotal: true
    };

    toggleSettings() {
        const { showSettings } = this.state;
        this.setState({ showSettings: !showSettings });
    }

    render() {

        const { init, total, changeNumColumns, columns } = this.props;
        const { showValues, showValuesOnBeads, showTotal, showSettings } = this.state;

        return (
            <Container fluid>
                <Container>
                    <Jumbotron>
                        {showTotal && <p className="total-value bg-white float-right">{total}</p>}
                        <h1>Sandbox Mode</h1>
                        <p>Move beads around and see how the value changes</p>
                        <Card>
                            <CardBody>
                                <Abacus showValues={showValues} showValuesOnBeads={showValuesOnBeads} />
                            </CardBody>
                        </Card>
                        <Button id="btn-settings" className="float-right" onClick={this.toggleSettings}>Settings</Button>

                    </Jumbotron>
                    <Popover target="btn-settings" className="settings" placement="auto-end" isOpen={showSettings} toggle={this.toggleSettings}>

                        <PopoverHeader color="bg-info">
                            <CardTitle> Settings </CardTitle>
                        </PopoverHeader>

                        <PopoverBody>
                            <ListGroup>
                                <ListGroupItem className="btn btn-light" onClick={() => this.setState({ showValues: !showValues })}>
                                    <CustomCheckBox checked={showValues}>
                                        Show Values
                                    </CustomCheckBox>
                                </ListGroupItem>
                                <ListGroupItem className="btn btn-light" onClick={() => this.setState({ showTotal: !showTotal })}>
                                    <CustomCheckBox checked={showTotal}>
                                        Show total Value
                                    </CustomCheckBox>
                                </ListGroupItem>
                                <ListGroupItem className="btn btn-light" onClick={() => this.setState({ showValuesOnBeads: !showValuesOnBeads })}>
                                    <CustomCheckBox checked={showValuesOnBeads}>
                                        Show Values on beads
                                    </CustomCheckBox>
                                </ListGroupItem>
                                <ListGroupItem>
                                    <ListGroupItemHeading>Columns</ListGroupItemHeading>
                                    <Slider tooltip min={1} max={8} value={columns} onChange={changeNumColumns} />
                                </ListGroupItem>
                                <ListGroupItem>
                                    <Button color="danger" onClick={() => init()}>Reset Values</Button>
                                </ListGroupItem>

                            </ListGroup>
                        </PopoverBody>
                    </Popover>

                </Container>

            </Container>
        );
    }

    static propTypes = {
        init: PropTypes.func,
        changeNumColumns: PropTypes.func,
        total: PropTypes.number,
        columns: PropTypes.number
    }

    static defaultProps = {
        allowSettings: false
    }
}

/**
 * Maps the Redux state to the SandboxMode component
 *
 * @param {SandboxModeState} state
 * @param {any} ownProps
 * @returns {any}
 */
function mapStateToProps(state) {
    const { total, columns } = state.abacus;

    return {
        total,
        columns: Object.keys(columns).length
    };
}

export default connect(mapStateToProps, { init, changeNumColumns })(SandboxMode);
