import React from 'react';
import { Jumbotron, Container } from 'reactstrap';

export default function NotFound404() {

    return (
        <Container>
            <Jumbotron>
                <h1>Page not found</h1>
                <div>
                    {"Oh no! This page doesn't exist"}
                </div>
            </Jumbotron>
        </Container>
    );
}