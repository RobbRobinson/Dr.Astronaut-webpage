import React from 'react';
import { PageLayout } from "../../util";


export default function Learn() {
    return (
        <PageLayout>
            <h1>Learn how to use the abacus</h1>

            <div>
                Videos and instructions can go here
                <div>
                    <iframe width="560" height="315" title="division" src="https://www.youtube.com/embed/C9Gw7FJDB20" frameBorder="0" allow="autoplay; encrypted-media" allowFullScreen />
                </div>
                <div>
                    <iframe width="560" height="315" title="multiplication" src="https://www.youtube.com/embed/wjxZb_fJLJ0" frameBorder="0" allow="autoplay; encrypted-media" allowFullScreen />
                </div>
            </div>
        </PageLayout>
    );
}
