import React from 'react';
import PropTypes from 'prop-types';
import { ListGroup, ListGroupItem } from 'reactstrap';

import PageLayout from './../../util/PageLayout';
import { Link } from 'react-router-dom';

function ListItem({ children }) {
    return (
        <ListGroupItem>
            {children}
            {/* <ListGroupItemText>{children}</ListGroupItemText> */}
        </ListGroupItem>
    );
}

ListItem.propTypes = {
    children: PropTypes.object.isRequired
};

export default function About() {
    return (
        <PageLayout>
            <h1>About</h1>
            <div>
                <p>This project is for Software Engineering I - CS 2450 at UVU, Spring 2018.</p>
                <p>
                    The purpose of this app is to be a useful way to learn how to do basic math on an abacus.<br />
                    To just mess around, go to the <Link to="/sandbox">sandbox</Link>.<br />
                    To learn how to use it, go to the <Link to="/learn">learning center</Link>.<br />
                    To take a quiz, click <Link to="/start">here</Link>.
                </p>

                <h2>Contributors:</h2>

                <ListGroup>

                    <ListItem>Josh DeGraw</ListItem>
                    <ListItem>Rob Robinson</ListItem>
                    <ListItem>Brandon Wright</ListItem>
                    <ListItem>Tyler Wray</ListItem>
                    <ListItem>Josh Wallace</ListItem>
                </ListGroup>
            </div>

            <div>Version {process.env.REACT_APP_VERSION}</div>

        </PageLayout>);
}
