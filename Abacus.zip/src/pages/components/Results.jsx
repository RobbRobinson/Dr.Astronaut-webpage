import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Table } from 'reactstrap';

import { Icon } from 'react-font-awesome-5';

const styles = {
    table: {
        maxWidth: '600px',
        border: '1px solid lightgray',
        margin: '100px auto',
        textAlign: 'center'
    },
    headerRow: {
        fontSize: '18px'
    },
    row: {
        fontSize: '18px',
        textAlign: 'center'
    },
    answer: {
        color: 'white',
        padding: '5px'
    },
    wrongAnswer: {
        color: 'red',
        marginLeft: '3px'
    },
    rightAnswer: {
        color: 'green'
    }
};

const Results = ({ results }) => (
    <Table striped style={styles.table}>
        <thead>
            <tr style={styles.headerRow}>
                <th>#</th>
                <th>Equation</th>
                <th>Correct Answer</th>
                <th>Your Answer</th>
                <th>Correct</th>
            </tr>
        </thead>
        <tbody>
            {results.map((result, key) => {
                return (
                    <tr style={styles.row} key={key}>
                        <th scope="row">{key + 1}</th>
                        <td>{result.equation}</td>
                        <td>{result.expectedResult}</td>
                        <td>{result.answer}</td>
                        <td>{result.correct ? <span style={{ ...styles.answer, ...styles.rightAnswer }}><Icon.Check /></span> : <span style={{ ...styles.answer, ...styles.wrongAnswer }}><Icon.Times /></span>}</td>
                    </tr>
                );
            })}
        </tbody>
    </Table>
);

Results.propTypes = {
    results: PropTypes.array
};

const mapStateToProps = (state) => {
    return { results: state.quiz.results };
};

export default connect(mapStateToProps)(Results);
