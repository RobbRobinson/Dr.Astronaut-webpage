import React from 'react';
import {
    Container, Jumbotron, Button,
    Card, CardBody, CardDeck, CardTitle, CardText, CardFooter, CardSubtitle, CardLink, 
    Row, Col,
    UncontrolledTooltip as Tooltip
} from 'reactstrap';

import { Link } from 'react-router-dom';
import { Icon } from 'react-font-awesome-5';

import './style/home.css';

const ICON_SIZE = '5x';

class Home extends React.Component {

    state = {
        showSandboxTooltip: false,
        showLearnTooltip: false,
        showQuizTooltip: false
    }

    render() {

        const { showSandboxTooltip, showLearnTooltip, showQuizTooltip } = this.state;
        return (
            <Container>
                <Jumbotron>

                    <Card style={{ margin: '0 auto' }}>
                        <CardBody style={{ margin: '0 auto' }}>
                            <Row>
                                <CardDeck>
                                    <Card body>
                                        <Button color="primary" id="btn-quiz" className="home-btn" tag={Link} to="/start">
                                            <Icon.FileAlt size={ICON_SIZE} />
                                        </Button>
                                        {/* <Tooltip target="btn-quiz" delay={0} placement="left">Take the quiz</Tooltip> */}
                                        <CardTitle>Quiz</CardTitle>
                                        <CardText>Take your quiz!</CardText>
                                    </Card>
                                    <Card body>
                                        <Button color="success" id="btn-learn" className="home-btn" tag={Link} to="/learn" role="button">
                                            <Icon.GraduationCap size={ICON_SIZE} />
                                        </Button>
                                        {/* <Tooltip target="btn-learn" delay={0} placement="auto-end">Learn how to use it</Tooltip> */}
                                        <CardTitle>Learn</CardTitle>
                                        <CardText>Videos on how to use the abacus</CardText>
                                        
                                    </Card>
                                    <Card body>
                                        <Button color="danger" id="btn-sandbox" className="home-btn" tag={Link} to="/sandbox" role="button">
                                            <Icon.Play size={ICON_SIZE} />                                         
                                        </Button>
                                        {/* <Tooltip target="btn-sandbox" delay={0} placement="right">Play with the Abacus</Tooltip> */}
                                        <CardTitle>Sandbox</CardTitle>
                                        <CardText>Free play</CardText>
                                        
                                    </Card>
                                </CardDeck>
                            </Row>
                        </CardBody>
                    </Card>
                </Jumbotron>
            </Container>
        );
    }
}

export default Home;
