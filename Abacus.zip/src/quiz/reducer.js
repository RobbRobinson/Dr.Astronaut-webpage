/** @module quiz/reducer */
import { EASY } from './util';
import { CHANGE_DIFFICULTY, ADD_RESULT, RESET_QUIZ_RESULTS } from './actions';
export const initialState = {
    difficulty: EASY,
    results: []
};
/**
 * @typedef QuizState @type {object}
 */

/**
 *
 *
 * @export
 * @param {QuizState} [state=initialState]
 * @param {any} action
 * @returns {QuizState}
 */
export default function quizReducer(state = initialState, action) {
    switch(action.type){
        case CHANGE_DIFFICULTY:
            return {
                ...state,
                difficulty: action.payload
            };
        case ADD_RESULT:
            return {
                ...state,
                results: [...state.results, action.result]
            };

        case RESET_QUIZ_RESULTS:
            return {
                ...state,
                results: []
            };

        default:
            return state;
    }
}
