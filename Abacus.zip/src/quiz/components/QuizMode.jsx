import React, { Component } from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import {
    Container, Col, Row, Jumbotron,
    Button, ButtonToolbar,
    Card, CardBody
} from 'reactstrap';

import { addResult, resetQuizResults } from './../actions';

import { init } from '../../Abacus/actions';
import Abacus from '../../Abacus';
import { getRandomInt } from '../../util';
import {
    EASY, INTERMEDIATE, HARD, ADVANCED, MASTER,
    ADD, SUBTRACT, MULTIPLY, DIVIDE,
    difficulties
} from '../util';

/**
 * @typedef {"×" | "÷" | "+" | "-"} Operator
 *
 * @typedef QuizModeProps @type {object}
 */


const QUIZ_LENGTH = 10;

/**
 * The view in which to take the quiz
 *
 * @class QuizMode
 * @extends {Component<QuizModeProps>}
 * @kind class
 * @export
 */
class QuizMode extends Component {
    /**
    * Creates an instance of QuizMode.
    * @param {QuizModeProps} props
    * @constructor
    * @kind member
    * @memberof QuizMode
    */
    constructor(props) {
        super(props);

        // Reset the abacus for quiz mode
        const { difficulty } = props;

        const config = difficulties[difficulty];
        const { firstNum, operator, secondNum } = this.generateValues(config);


        this.state = {
            firstNum,
            secondNum,
            questionNum: 1,
            operator,
            config,
            results: []
        };

        this.resetEquation = this.resetEquation.bind(this);
        this.handleNextClick = this.handleNextClick.bind(this);
    }

    static propTypes = {
        init: PropTypes.func,
        difficulty: PropTypes.oneOf([EASY, INTERMEDIATE, HARD, ADVANCED, MASTER]),
        total: PropTypes.number,
        addResult: PropTypes.func.isRequired,
        resetQuizResults: PropTypes.func.isRequired
    }

    static defaultProps = {
        difficulty: EASY
    }

    componentDidMount() {
        this.props.resetQuizResults();
        this.resetEquation(true);
    }

    /**
    * Generates two random values to be used in the equation, and the operator to apply to them
    *
    * @returns {{ firstNum: number, operator:Operator, secondNum: number }}  An object containing the first number, the operator, and the second number, in that order
    * @param {any} config
    * @memberof QuizMode
    */
    generateValues(config) {

        const operator = this.generateOperator(config);

        let [firstNum, secondNum] = [0, 0];

        const { left, right, advanced } = config.constraints;

        switch (operator) {
            case ADD:
            case SUBTRACT:
                firstNum = getRandomInt(left.min, left.max);
                secondNum = getRandomInt(right.min, right.max);
                break;

            case MULTIPLY:
            case DIVIDE: {
                const { left, right } = advanced;
                firstNum = getRandomInt(left.min, left.max);
                secondNum = getRandomInt(right.min, right.max);
            }
                break;
            default:
                break;
        }

        // Make sure the result is always positive
        if (secondNum > firstNum)
            [firstNum, secondNum] = [secondNum, firstNum];

        return { firstNum, operator, secondNum };
    }

    /**
     * Randomly returns either the multiplication or division sign
     *
     * @returns {"×" | "÷" | "+" | "-"}
     * @memberof QuizMode
     */
    generateOperator(config) {
        const allowedOperators = config.operators;

        if (allowedOperators.length === 1)
            return allowedOperators[0];

        const index = getRandomInt(0, allowedOperators.length);
        return allowedOperators[index];
    }

    get expectedResult() {
        const { firstNum, operator, secondNum } = this.state;

        switch (operator) {
            case MULTIPLY: return Math.round(firstNum * secondNum);
            case ADD: return Math.round(firstNum + secondNum);
            case SUBTRACT: return Math.round(firstNum - secondNum);

            case DIVIDE: {
                const res = Math.round(firstNum / secondNum);
                const rem = firstNum % secondNum;

                return [res, rem];
            }

            default:
                throw new Error("Invalid operator");
        }
    }

    /**
     * Gets the current equation to be calculated
     *
     * @readonly
     * @memberof QuizMode
     */
    get equation() {
        const {
            firstNum,
            secondNum,
            operator
        } = this.state;

        return `${firstNum} ${operator} ${secondNum}`;
    }

    /**
     * Resets the abacus, and optionally changes the equation.
     * 
     * @param {boolean} changeEquation If true, randomly assign new values for firstNum, operator, and secondNum
     * @memberof QuizMode
     */
    resetEquation(changeEquation = false) {
        const { init } = this.props;
        const { config } = this.state;
        if (changeEquation) {
            const { firstNum, operator, secondNum } = this.generateValues(config);
            this.setState({ firstNum, operator, secondNum });
        }
        init({ columns: config.columns });
    }

    /**
     * 
     *
     * @memberof QuizMode
     */
    handleNextClick() {
        const { total, addResult } = this.props;
        const { results, questionNum, operator } = this.state;
        
        const roundedTotal = Math.round(total);

        let expectedResult = this.expectedResult;
        let correct = false;

        if (operator === DIVIDE) {
            const [res, rem] = expectedResult;
            correct = res === total;
            if (rem !== 0) {
                expectedResult = `${res}, Remainder ${rem}`;
            }
            else {
                expectedResult = `${res}`;
            }
        }
        else {
            correct = expectedResult === roundedTotal;
        }

        const nextResults = {
            equation: this.equation,
            expectedResult,
            answer: total,
            correct
        };

        addResult(nextResults);

        this.setState({
            questionNum: questionNum + 1,
            results: [
                ...results,
                nextResults
            ]
        });
        this.resetEquation(true);
    }

    render() {
        const { difficulty } = this.props;
        const { questionNum, results } = this.state;
        return (
            <Container>
                <Jumbotron>
                    <p className="total-value bg-white float-right">{this.equation}</p>
                    <h1>Quiz mode</h1>
                    <h3>Question #{questionNum}</h3>
                    <p>Move the beads to match the equation</p>
                    <p>Difficulty: {difficulty}</p>
                    <Row>
                        <Col>
                            <Card>
                                <CardBody>
                                    <Abacus />
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <div className="flex-center mt-2">
                                <ButtonToolbar>
                                    <Button hidden={results.length + 1 >= QUIZ_LENGTH} color="danger" onClick={() => this.resetEquation(false)}>Reset</Button>
                                    <Button hidden={results.length + 1 >= QUIZ_LENGTH} color="primary" className="mx-2" onClick={this.handleNextClick}>Next</Button>
                                    <Button hidden={results.length + 1 < QUIZ_LENGTH} color="success" tag={Link} to="/results" onClick={this.handleNextClick}>Done</Button>
                                </ButtonToolbar>
                            </div>
                        </Col>
                    </Row>
                </Jumbotron>
            </Container>);
    }
}

function mapStateToProps(state) {

    const { total } = state.abacus;
    const { difficulty } = state.quiz;
    return {
        difficulty,
        total
    };
}

export default connect(mapStateToProps, { init, addResult, resetQuizResults })(QuizMode);
