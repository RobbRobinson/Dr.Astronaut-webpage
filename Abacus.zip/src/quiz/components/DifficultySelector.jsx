import React, { Component } from 'react';
import Slider from 'react-rangeslider';
import { Container, Jumbotron, Button, Card, CardBody, CardFooter } from 'reactstrap';
import { Link } from 'react-router-dom';

import 'react-rangeslider/lib/index.css';

import { DIFFICULTY_MAP, DIFFICULTY_MAP_INVERSE } from '../util';
import { connect } from 'react-redux';
import { changeDifficulty } from './../actions';
import PropTypes from 'prop-types';

class DifficultySelector extends Component {

    constructor(props) {
        super(props);

        this.handleValueChange = this.handleValueChange.bind(this);
    }

    handleValueChange(value) {
        const { changeDifficulty } = this.props;
        changeDifficulty(DIFFICULTY_MAP[value]);
    }

    static propTypes = {
        difficulty: PropTypes.number,
        changeDifficulty: PropTypes.func
    }

    render() {
        const sliderLabels = DIFFICULTY_MAP;
        const { difficulty } = this.props;
        return (
            <Container>
                <Jumbotron>
                    <h1>Select Difficulty</h1>
                    <Card>
                        <CardBody>
                            <Slider
                                step={25}
                                tooltip={false}
                                value={difficulty}
                                onChange={this.handleValueChange}
                                labels={sliderLabels} />

                        </CardBody>

                        <CardFooter>
                            <Button tag={Link} color="primary" to="/quiz">
                                Start!
                            </Button>
                        </CardFooter>
                    </Card>
                </Jumbotron>
            </Container>
        );
    }
}

function mapStateToProps(state) {

    const { difficulty } = state.quiz;
    const nextDif = DIFFICULTY_MAP_INVERSE[difficulty];
    return {
        difficulty: nextDif
    };
}

export default connect(mapStateToProps, { changeDifficulty })(DifficultySelector);