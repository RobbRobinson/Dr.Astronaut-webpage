export const CHANGE_DIFFICULTY = 'CHANGE_DIFFICULTY';
export const RECORD_ANSWER = 'RECORD_ANSWER';
export const ADD_RESULT = 'ADD_RESULT';
export const RESET_QUIZ_RESULTS = 'RESET_QUIZ_RESULTS';



export function changeDifficulty(difficulty) {

    return {
        type: CHANGE_DIFFICULTY,
        payload: difficulty
    };
}

export function addResult(result) {
    return {
        type: ADD_RESULT,
        result
    };
}


export function resetQuizResults(){
    return {
        type: RESET_QUIZ_RESULTS
    };
}