/** @namespace quiz */
/**
 * @module util
 */
import invert from 'lodash/invert';
import mapValues from 'lodash/mapValues';

export const ADVANCED_MAX_VAL = 99;
export const INTERMED_MAX_VAL = 50;
export const EASY_MAX_VAL = 12;
export const SECOND_NUMBER_MAX_VAL = 10;

export const MULTIPLY = '×';
export const DIVIDE = '÷';
export const ADD = '+';
export const SUBTRACT = '-';

/**
 * 2 columns
 * 
 * Addition:                1..9
 */
export const EASY = 'Easy';

/**
 * 2 columns
 * Addition, subtraction:   1..20
 */
export const INTERMEDIATE = 'Medium';

/**
 * 4 columns
 * Addition & subtraction:  1..99
 * Multiply:                1..9
 */
export const HARD = 'Hard';

/**
 * 6 columns
 * Addition & subtraction:  1..99
 * Multiply & divide:       1..20 : 1..9
 */
export const ADVANCED = 'Super Hard';


/**
 * 8 columns
 * Addition & subtraction:  1..99
 * Multiply & divide:       1..99
 */
export const MASTER = 'Master';

/**
 * Configuration options for each difficulty
 * @export
 */
export const difficulties = {
    [EASY]: {
        columns: 2,
        operators: [ADD],
        constraints: {
            left: {
                min: 1,
                max: 9
            },
            right: {
                min: 1,
                max: 9
            },            
            advanced: null
        }
    },
    [INTERMEDIATE]: {
        columns: 2,
        operators: [ADD, SUBTRACT],

        constraints: {
            left: {
                min: 1,
                max: 20
            },
            right: {
                min: 1,
                max: 20
            },
            advanced: null
            
        }
    },
    [HARD]: {

        columns: 4,
        operators: [ADD, SUBTRACT, MULTIPLY],

        constraints: {
            left: {
                min: 1,
                max: 99
            },
            right: {
                min: 1,
                max: 99
            },
            advanced: {

                left: {
                    min: 1,
                    max: 10
                },
                right: {
                    min: 1,
                    max: 10
                }
            }
        }
    },
    [ADVANCED]: {

        columns: 6,
        operators: [ADD, SUBTRACT, MULTIPLY, DIVIDE],

        constraints: {
            left: {
                min: 1,
                max: 99
            },
            right: {
                min: 1,
                max: 99
            },
            advanced: {
                left: {
                    min: 1,
                    max: 20
                },
                right: {
                    min: 1,
                    max: 10
                }
            }
        }
    },

    [MASTER]: {

        columns: 8,
        operators: [ADD, SUBTRACT, MULTIPLY, DIVIDE],

        constraints: {
            left: {
                min: 1,
                max: 99
            },
            right: {
                min: 1,
                max: 99
            },
            advanced: {

                left: {
                    min: 1,
                    max: 20
                },
                right: {
                    min: 1,
                    max: 10
                }
            }
        }
    }
};


/**
 * 
 * Key into this object with the number to get its difficulty name
 */
export const DIFFICULTY_MAP = {
    0: EASY,
    25: INTERMEDIATE,
    50: HARD,
    75: ADVANCED,
    100: MASTER
};

/**
 * Key into this object with the name of the difficulty to get its numerical value
 */
export const DIFFICULTY_MAP_INVERSE = mapValues(invert(DIFFICULTY_MAP), parseInt);
