
//    ___     _             _     ___     _    _                         
//   | _ \___| |__  ___ _ _| |_  | _ \___| |__(_)_ _  ___ ___ _ _        
//   |   / _ \ '_ \/ -_) '_|  _| |   / _ \ '_ \ | ' \(_-</ _ \ ' \       
//   |_|_\___/_.__/\___|_|__\__| |_|_\___/_.__/_|_||_/__/\___/_||_|      
//   \ \    / /__| |__  |_  ) __| __|/  \                                
//    \ \/\/ / -_) '_ \  / /|__ \__ \ () |                               
//     \_/\_/\___|_.__/ /___|___/___/\__/                                
//    ___          __ _ _       ____                                     
//   | _ \_ _ ___ / _(_) |___  |__ /                                     
//   |  _/ '_/ _ \  _| | / -_)  |_ \                                     
//   |_|_|_|_\___/_|_|_|_\___| |___/_                          _         
//    / __| _ \_ _|   \   _| |_  | _ \___ ____ __  ___ _ _  __(_)_ _____ 
//   | (_ |   /| || |) | |_   _| |   / -_|_-< '_ \/ _ \ ' \(_-< \ V / -_)
//    \___|_|_\___|___/    |_|   |_|_\___/__/ .__/\___/_||_/__/_|\_/\___|
//                                          |_|                          



$("#footer").collapse("toggle"); // not currently jumpping page up to immediatly show my hiddent footer content







//               _ _      _____     _    _     
//   __ __ ___ _(_) |_ __|_   _|_ _| |__| |___ 
//   \ V  V / '_| |  _/ -_)| |/ _` | '_ \ / -_)
//    \_/\_/|_| |_|\__\___||_|\__,_|_.__/_\___|
//                                             

function writeTable(container) {


    if (JSON.parse(localStorage.getItem("SiteVisitors")) == undefined) {

        
        // // take the newly filled array and 'set' it into local storage. 
        localStorage.setItem("SiteVisitors", JSON.stringify(jsonArrayOfPeopleObjs));
        // end of 'on-off commenting' section.

        // get wizards out of local storage.
        jsonArrayOfPeopleObjs = JSON.parse(localStorage.getItem("SiteVisitors"));

        // resetablish each item here as a 'true Person obj'
        $.each(jsonArrayOfPeopleObjs, function(index, person) {
            person.__proto__ = Person.prototype;
        });

    }
    else {
        // this one here brings them out of storage each time. just like pickling in python.
        // DO NOT UNCOMMENT THIS ONE. JUST THE STORAGE SETTER ABOVE FOR INITIALLY LOADING YOUR STORAGE.
        jsonArrayOfPeopleObjs = JSON.parse(localStorage.getItem("SiteVisitors"));

        // resetablish each item here as a 'true Person obj'
        $.each(jsonArrayOfPeopleObjs, function(index, person) {
            person.__proto__ = Person.prototype;
        });

    }

    // display message if there are no SiteVisitors in the database, either because local storage has not been primed, or because you've just successfully deleted them all. if so congrats.
    if (jsonArrayOfPeopleObjs == null) {
        alert("Sorry there are no Site Visitors in your Data Base... "); // make sure if table is empty te user is notified of no existing Wizards.
       
        localStorage.removeItem("SiteVisitors")
    }
    else { // else if there are SiteVisitors to show, SHOW EM!!

        renderRobsTable($(container), "FSiteVisitors", jsonArrayOfPeopleObjs);
    }

    // return nothing here because the renderTable function performs the output at the end of its function.
}



//                    _           ___     _    _      _        _    _     
//    _ _ ___ _ _  __| |___ _ _  | _ \___| |__( )___ | |_ __ _| |__| |___ 
//   | '_/ -_) ' \/ _` / -_) '_| |   / _ \ '_ \/(_-< |  _/ _` | '_ \ / -_)
//   |_| \___|_||_\__,_\___|_|   |_|_\___/_.__/ /__/  \__\__,_|_.__/_\___|
//                                                                        

// header demo : firstName, lastName, address, city, state, zip, id
// Person demo : Albus, Dumbldore, Hogwarts, Godrick's Hollow, hidden, unknown Zip, 1

// keep asking yourself "what am i holding?"

function renderRobsTable(container, label, DATA) {

    //console.log("test : i made it into rendertable");


    //    _        _    _     
    //   | |_ __ _| |__| |___ 
    //   |  _/ _` | '_ \ / -_)
    //    \__\__,_|_.__/_\___|
    //                        
    // create a table class obj.
    var $table = $("<table id='WizTable' />").addClass("table").addClass("table-hover").addClass("table-bordered").addClass("table-striped").addClass("table-responsive");

    // set the table attribute "id" to the string passed in.
    //$table.attr("id", label);


    //    _                _         
    //   | |_  ___ __ _ __| |___ _ _ 
    //   | ' \/ -_) _` / _` / -_) '_|
    //   |_||_\___\__,_\__,_\___|_|  
    //                               
    // create a table header to append to the table body.
    var $header = $("<thead/>").addClass("thead-dark");

    $("<tr>").appendTo($header);
    $("<th scope='col'>" + 'id' + "</th>").appendTo($header).hide(); // hide the 'id' element of the row
    $("<th scope='col'>" + 'Full Name' + " <i class='fas fa-bolt'></i></th>").appendTo($header);
    $("<th scope='col'>" + 'Full Address' + "</th>").appendTo($header);
    $("<th scope='col'>" + 'Phone' + "</th>").appendTo($header);
    $("<th scope='col'>" + 'Email' + "</th>").appendTo($header);
    $("<th scope='col'>" + 'Actions  ' + "</th></tr></thead>").appendTo($header);

    // append to table 
    $table.append($header);

    //    _   _             _      
    //   | |_| |__  ___  __| |_  _ 
    //   |  _| '_ \/ _ \/ _` | || |
    //    \__|_.__/\___/\__,_|\_, |
    //                        |__/ 
    // create a table body.
    var $tbody = $("<tbody/>");

    //                   
    //    _ _ _____ __ __
    //   | '_/ _ \ V  V /
    //   |_| \___/\_/\_/ 
    //                   

    // using DATA, create rows, to append to the table body.
    $.each(DATA, function(rowIndex, rowItem) { // rowItem is a person at this point

        // create a jQuery row object of Bootstrap type <tr> 
        var $row = $("<tr/ onClick='Edit(" + rowItem.id + ")'>");

        // create a head elememt to hodl the id fiels
        $("<th id='$row' scope='row'>" + rowItem.id + "</th>").appendTo($row).hide();
        $("<td>" + rowItem.fullName() + "</td>").appendTo($row);
        $("<td>" + rowItem.fullAddress() + "</td>").appendTo($row);
        $("<td>" + rowItem.phone + "</td>").appendTo($row);
        $("<td>" + rowItem.email + "</td>").appendTo($row);
        // // edit & delete
        $("<td><a href='#' data-toggle='modal' data-target='#myModal' onClick='event.stopPropagation; Edit(" + rowItem.id + ")'><i class='fas fa-quidditch'></i></a>" +
            "      " +
            "<a href='#' onClick='event.stopPropagation(); Delete(" + rowItem.id + ")'><i class='far fa-trash-alt'></i></a></td>" + "</tr>").appendTo($row);

        $tbody.append($row); // we finally have all the field's of the wizards, we can now append it to a row 
    });

    $table.append($tbody);

    // RETURN THE TABLE WRAPPED IN HTML TO THE PAGE CONTAINER.
    // populates the container in html file with the newly made table.

    return container.append("<div></i><h3>" + label + "</h3></div>").append($table);
}




//         _     _          _                   
//    __ _| |___| |__  __ _| | __ ____ _ _ _ ___
//   / _` | / _ \ '_ \/ _` | | \ V / _` | '_(_-<
//   \__, |_\___/_.__/\__,_|_|  \_/\__,_|_| /__/
//   |___/                                      

// I know this is taboo overall but for current functionality reasons im using a globally defined variable.
// So that i can easily pass a parameter bewteen funcitnos.
var selectedPerson;

//      _                            __   ___              _     
//     /_\  _ _ _ _ __ _ _  _   ___ / _| | _ \___ ___ _ __| |___ 
//    / _ \| '_| '_/ _` | || | / _ \  _| |  _/ -_) _ \ '_ \ / -_)
//   /_/ \_\_| |_| \__,_|\_, | \___/_|   |_| \___\___/ .__/_\___|
//                       |__/                        |_|         

// create an array to hold Json obj's
// an array to hold my Person objects // index[0]=column headers, the rest below are rows
var jsonArrayOfPeopleObjs = []; // this will hold the objects that i will create below so that they can persist after rendertable is finished.


//    ___                         ___  _     _        _   
//   | _ \___ _ _ ___ ___ _ _    / _ \| |__ (_)___ __| |_ 
//   |  _/ -_) '_(_-</ _ \ ' \  | (_) | '_ \| / -_) _|  _|
//   |_| \___|_| /__/\___/_||_|  \___/|_.__// \___\__|\__|
//                                        |__/            

// Person demo : Albus, Dumbldore, Hogwarts, Godrick's Hollow, hidden, unknown Zip, 1
function Person(id = "#", first = "#", last = "#", address = "#", city = "#", state = "#", zip = "#", phone = "#", email = "#", user = "#", password = "#") {
    // though this says function it can act as an object by accessing its data members using this. 
    // a javascripts function can act as a class would in other lang's.

    this.id = id;
    this.firstName = first;
    this.lastName = last;
    this.address = address;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.phone = phone;
    this.email = email;
    this.userName = user;
    this.pass = password; // this doesnt sound safe. i should review possible plugins for masking or encryption.

    // will soon also have the following attributes :

    //this.rbc = rbc; // Radio Button Choice
    //this.cxb = checkboxes;

    // this results in a JSON object
}


//    ___     _ _   _  _                 ____  
//   | __|  _| | | | \| |__ _ _ __  ___ / /\ \ 
//   | _| || | | | | .` / _` | '  \/ -_) |  | |
//   |_| \_,_|_|_| |_|\_\__,_|_|_|_\___| |  | |
//                                      \_\/_/ 

Person.prototype.fullName = function() {
    return this.firstName + " " + this.lastName;
}


//    ___     _ _     _      _    _                ____  
//   | __|  _| | |   /_\  __| |__| |_ _ ___ ______/ /\ \ 
//   | _| || | | |  / _ \/ _` / _` | '_/ -_|_-<_-< |  | |
//   |_| \_,_|_|_| /_/ \_\__,_\__,_|_| \___/__/__/ |  | |
//                                                \_\/_/ 

Person.prototype.fullAddress = function() {
    return this.address + ", " + this.city + ", " + this.state + ", " + this.zip;
}






//    _  _              ___                          _              _   __  __         _      _ 
//   | \| |_____ __ __ | _ \___ _ _ ___ ___ _ _     | |___  __ _ __| | |  \/  |___  __| |__ _| |
//   | .` / -_) V  V / |  _/ -_) '_(_-</ _ \ ' \ _  | / _ \/ _` / _` | | |\/| / _ \/ _` / _` | |
//   |_|\_\___|\_/\_/  |_| \___|_| /__/\___/_||_( ) |_\___/\__,_\__,_| |_|  |_\___/\__,_\__,_|_|
//                                              |/                                              

// NewPerson

$("#NewPerson").on("click", function(event) {
    // make sure no wizards are still in the form
    document.getElementById('VisitorForm').reset();

    // // load modal with default of "Big Bird"
    // $("#myModal").modal('toggle'); // opens modal

    // create a new person from the forms fields
    selectedPerson = new Person();

    // get wiz id
    selectedPerson.id = getNewPersonID();
});


//   __      ___      ___ ___   ____  
//   \ \    / (_)___ |_ _|   \ / /\ \ 
//    \ \/\/ /| |_ /  | || |) | |  | |
//     \_/\_/ |_/__| |___|___/| |  | |
//                             \_\/_/ 

// helper func to 'NewPerson()'
function getNewPersonID() {
    return Math.floor(Math.random() * 10000).toString();
}


//       _               ____  
//    __| |_  _ _ __ ___/ /\ \ 
//   / _` | || | '_ (_-< |  | |
//   \__,_|\_,_| .__/__/ |  | |
//             |_|      \_\/_/ 

// helper function to the save button. no accepting duplicate wizards in the list.
function dups(selectedPerson) {
    console.log("data at the time prior to dups");
    console.log(jsonArrayOfPeopleObjs);
    console.log(selectedPerson);
    
    for (let person in jsonArrayOfPeopleObjs) {
        if (person.id == selectedPerson.id) {
            alert("we have a duplicate Wizard");
            return true;
        }
    }
}


//    ___               ____            _        _          _ ___                      
//   | __|__ _ _ _ __   \ \ \   ___ ___| |___ __| |_ ___ __| | _ \___ _ _ ___ ___ _ _  
//   | _/ _ \ '_| '  \   > > > (_-</ -_) / -_) _|  _/ -_) _` |  _/ -_) '_(_-</ _ \ ' \ 
//   |_|\___/_| |_|_|_| /_/_/  /__/\___|_\___\__|\__\___\__,_|_| \___|_| /__/\___/_||_|
//                                                                                     

function loadFormDataInto(selectedPerson) {

    // A SETTER FUNCTION TO TAKE THE FORMS DATA AND PUT IT INTO A USABLE PERSON.

    selectedPerson.id = $("#id").val();
    selectedPerson.firstName = $("#firstName").val();
    selectedPerson.lastName = $("#lastName").val();
    selectedPerson.address = $("#address").val();
    selectedPerson.city = $("#city").val();
    selectedPerson.state = $("#state").val();
    selectedPerson.zip = $("#zip").val();
    selectedPerson.phone = $("#phone").val();
    selectedPerson.email = $("#email").val();
    selectedPerson.userName = $("#userName").val();
    selectedPerson.pass = $("#password").val();

}


//    ___      _   _              ___             _     _    _    _                         ___      _            _ 
//   | _ )_  _| |_| |_ ___ _ _   | __|_ _____ _ _| |_  | |  (_)__| |_ ___ _ _  ___ _ _ ___ | _ ) ___| |_____ __ _(_)
//   | _ \ || |  _|  _/ _ \ ' \  | _|\ V / -_) ' \  _| | |__| (_-<  _/ -_) ' \/ -_) '_(_-< | _ \/ -_) / _ \ V  V /_ 
//   |___/\_,_|\__|\__\___/_||_| |___|\_/\___|_||_\__| |____|_/__/\__\___|_||_\___|_| /__/ |___/\___|_\___/\_/\_/(_)
//                                                                                                                  



//    ___                   ___      _          _ _       ___         ___             _           _____     _    _       
//   / __| __ ___ _____    / __|_  _| |__ _ __ (_) |_    | _ \___ ___| _ \___ _ _  __| |___ _ _  |_   _|_ _| |__| |___   
//   \__ \/ _` \ V / -_)_  \__ \ || | '_ \ '  \| |  _|_  |   / -_)___|   / -_) ' \/ _` / -_) '_|   | |/ _` | '_ \ / -_)_ 
//   |___/\__,_|\_/\___( ) |___/\_,_|_.__/_|_|_|_|\__( ) |_|_\___|   |_|_\___|_||_\__,_\___|_|     |_|\__,_|_.__/_\___(_)
//                     |/                            |/                                                                  

// on submit of modal button, save info to mutate the EXISTING person object.
$("#VisitorForm").submit(function(event) {
    event.preventDefault(); //  this is to stop the form from submitting before i can perform my validations.

    // var temp = jsonArrayOfPeopleObjs.filter(person, person.name == selectedPerson.name );
    // if (temp == true){
    //     jsonArrayOfPeopleObjs.push(selectedPerson);
    // }

    // take the inputs from the form, mutate the existing obj
    selectedPerson.id = getNewPersonID().toString();
    selectedPerson.firstName = $("#firstName").val();
    selectedPerson.lastName = $("#lastName").val();
    selectedPerson.address = $("#address").val();
    selectedPerson.city = $("#city").val();
    selectedPerson.state = $("#state").val();
    selectedPerson.zip = $("#zip").val();
    selectedPerson.phone = $("#phone").val();
    selectedPerson.email = $("#email").val();
    selectedPerson.userName = $("#userName").val();
    selectedPerson.pass = $("#password").val();

    // push new wixard into table, reload  table.
    jsonArrayOfPeopleObjs.push(selectedPerson);

    // update local storage
    localStorage.setItem("SiteVisitors", JSON.stringify(jsonArrayOfPeopleObjs));

    alert("Thank you for saying Hello :)")

    $("#myModal").modal('toggle'); // closes it on submital

});




//      _ _     __  __        _   _                     _    ___                    _ _ _ _   _        
//    _| | |_  |  \/  |_  _  | | | |_ _ _  _ ___ ___ __| |  / __|__ _ _ __  __ _ __(_) (_) |_(_)___ ___
//   |_  .  _| | |\/| | || | | |_| | ' \ || (_-</ -_) _` | | (__/ _` | '_ \/ _` / _| | | |  _| / -_|_-<
//   |_     _| |_|  |_|\_, |  \___/|_||_\_,_/__/\___\__,_|  \___\__,_| .__/\__,_\__|_|_|_|\__|_\___/__/
//     |_|_|           |__/                                          |_|                               







//    ___      _     _           _   _ _ 
//   |   \ ___| |___| |_ ___    /_\ | | |
//   | |) / -_) / -_)  _/ -_)  / _ \| | |
//   |___/\___|_\___|\__\___| /_/ \_\_|_|
//                                       

// Similar to my delete func above, i just changed the way the array is sorted. clear & re-render table with Moody gif. (+3pts)
$("#DeleteAllButton").on("click", function() {
    // clear away entire table. replace with a alert that notifies the user that the table is empty.
    //$("#buttonRow").hide();

    // BEFORE IMMEDIATELY DELETING, VERIFY THE USER WANTS TO DELETE!
    // alert that they confirm with?
    var result = confirm("Are you sure you want to delete ALL Wizards?");

    // IF THEY DO WANT TO DELETE:
    if (result == true) {
        // only puts the wizard back into the list if their value was negative.
        // since we never assign negative values this should clear the table of all wizards.
        //jsonArrayOfPeopleObjs = jsonArrayOfPeopleObjs.filter(person => person.id < 0);

        // the real slim shady, cleans up storage.
        localStorage.removeItem("#");
        jsonArrayOfPeopleObjs = [];
    }
});

